package com.cts.training.day26;

public class ElseBeforeIf {

	public static void main(String[] args) {
		if (args.length > 0) {
			System.out.println("Java");
		} else {
			System.out.print("I Like ");
			String arr[] = { "A"};
			main(arr);
		}

	}

}