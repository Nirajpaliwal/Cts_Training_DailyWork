package com.cts.training.day26;

class A {
	private A() {

	}

	public void test2() {
		System.out.println("Task 2 of class A");
	}
}

public class Demo {

//	public void add(int c, int d) {
//		System.out.println("Hi");
//	}
//
//	public void add(float c, float d) {
//		System.out.println("Bye");
//	}
//
//	public void add(double c, double d) {
//		System.out.println("Hello");
//	}

	public static void main(String[] args) {
//		A obj = new A();
//		obj.test2();

		String str1 = "java";
		String str2 = new String("java");

		String str3 = "java";
		String str4 = new String("java");
		StringBuffer sb1 = new StringBuffer("java");
		StringBuffer sb2 = new StringBuffer("java");

		if (sb1.equals(sb2)) {
			System.out.println("Equal");
		} else {
			System.out.println("Not Equal");
		}

	}
}
