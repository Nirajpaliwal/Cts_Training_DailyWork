package com.cts.training.day26;

import java.io.FileReader;
import java.io.IOException;

public class ExceptionDemo {

	public void readData() throws IOException {
		FileReader fr = new FileReader("Emp.txt");
		int i = fr.read();
		System.out.println("Hi");
	}

	public void task2() throws IOException {
		readData();
	}

	public static void main(String[] args) {
		ExceptionDemo ed = new ExceptionDemo();
		try {
			ed.task2();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("End of main class");
	}

}
