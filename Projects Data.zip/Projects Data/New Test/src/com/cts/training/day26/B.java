package com.cts.training.day26;

interface C {
	int i;
	public void task();
}

class B implements C {
	public void task() {

	}

	public static void main(String[] args) {

	}
}
