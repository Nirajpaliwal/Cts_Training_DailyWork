package com.cts.training.day26;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;



public class SetDemo {

	public static void main(String[] args) {
		
		Map<Integer, String> map = new HashMap<>();
		map.put(3432, "abc@$");
		map.put(3432, "pqr@$");
		map.put(3432, "xyz@$");
		System.out.println(map);
		

		
		for (Entry<Integer, String> entry : map.entrySet()) {
			System.out.println("Key : " + entry.getKey() + " -->" + " Value : " + entry.getValue());
		}
		
//		Set set = new TreeSet();
//		set.add("one");
//		set.add("two");
//		set.add("three");
//		set.add("four");
//		set.add(2);
//		System.out.println(set);

	}

}
