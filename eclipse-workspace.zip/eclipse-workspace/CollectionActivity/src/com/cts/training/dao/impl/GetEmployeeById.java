package com.cts.training.dao.impl;

public class GetEmployeeById {

}
