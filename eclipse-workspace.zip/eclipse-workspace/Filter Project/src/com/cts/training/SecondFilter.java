package com.cts.training;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebServlet;

@WebFilter("/RequestHandlerServlet")
public class SecondFilter implements Filter {
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("from init of SecondFilter");

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		System.out.println("from doFilter of SecondFilter");
		System.out.println("request pre-processing from ----> SecondFilter");
		chain.doFilter(request, response);
		System.out.println("request post-processing from ----> SecondFilter");

	}

	@Override
	public void destroy() {
		System.out.println("from destroy of SecondFilter");

	}
}
