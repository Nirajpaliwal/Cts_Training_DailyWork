package com.cts.training.day26;

public class Test3 {

	public static void main(String[] args) {
		String p = "";
		if (p.isEmpty()) {
			System.out.println("a");;;;;;;;;;;;;;;;;;
		} else {
			System.out.println("b");;;;;;;;
		}
	}
}
