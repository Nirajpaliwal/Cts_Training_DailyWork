/**
 * 
 */

function displaySum() {
	document.write(calculateSum(2,2));
}

function calculateSum(num1, num2) {
	return num1 + num2;
}