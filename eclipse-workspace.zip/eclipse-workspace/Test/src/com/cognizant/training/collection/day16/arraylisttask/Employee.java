package com.cognizant.training.collection.day16.arraylisttask;

public class Employee {

}


