package com.cognizant.training.collection.day16;

import java.util.HashSet;

public class SetInterfaceDemo {
	HashSet<String> set = new HashSet<>();
	
	set.add("Hello");
	set.add("To");
	set.add("java");
	set.add("batch");
	set.add("5");
}
