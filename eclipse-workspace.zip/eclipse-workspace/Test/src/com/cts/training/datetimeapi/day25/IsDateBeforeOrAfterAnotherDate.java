// 12. How to see if a date is before or after another date

package com.cts.training.datetimeapi.day25;

import java.time.LocalDate;

public class IsDateBeforeOrAfterAnotherDate {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();

		LocalDate tommorow = LocalDate.of(2020, 3, 1);
		if (today.isBefore(tommorow)) {
			System.out.println("Today is before tomorrow : TRUE");
		}
		if (today.isAfter(tommorow)) {
			System.out.println("Today is after tomorrow : TRUE");
		}

	}
}
