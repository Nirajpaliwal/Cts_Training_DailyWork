// 14 . How to represent fixed date e.g. credit card expiry, YearMonth

package com.cts.training.datetimeapi.day25;

import java.time.Month;
import java.time.YearMonth;

public class CheckingCardExpiry {

	public static void main(String[] args) {
		YearMonth today = YearMonth.now();

		System.out.printf("The current %s : %d \t %n", today, today.getMonthValue());

		YearMonth creditExpiry = YearMonth.of(2020, Month.OCTOBER);
		System.out.println("Your Creadit Card Expiry is :" + creditExpiry);
	}

}
