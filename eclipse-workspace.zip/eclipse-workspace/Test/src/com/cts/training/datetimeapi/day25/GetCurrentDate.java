// 1. How to get today's date

package com.cts.training.datetimeapi.day25;

import java.time.LocalDate;

public class GetCurrentDate {

	public static void main(String[] args) {

		LocalDate date = LocalDate.now();
		System.out.println("\nDate : " + date);

	}

}
