package com.cts.training.datetimeapi.day25;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.MonthDay;

public class JodaDateTimeAPI {

	public static void main(String[] args) {

		

		

		

		

		

		
		
	}

}
