// 9. How to find Date after 1 week

package com.cts.training.datetimeapi.day25;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class FindDateAfterOneWeek {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();

		LocalDate next = today.plus(1, ChronoUnit.WEEKS);
		System.out.println("Today's date is :" + today);
		System.out.println("1 week Later date is :" + next);

	}

}
