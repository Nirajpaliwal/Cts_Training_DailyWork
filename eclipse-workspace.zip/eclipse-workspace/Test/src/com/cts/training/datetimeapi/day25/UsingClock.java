// 11. Using Clock

package com.cts.training.datetimeapi.day25;

import java.time.Clock;

public class UsingClock {

	public static void main(String[] args) {
		Clock clock = Clock.systemUTC();
		System.out.println("Clock : " + clock);// Clock :SystemClock[Z]

		Clock defaultClock = Clock.systemDefaultZone();
		System.out.println("Clock : " + defaultClock);// Clock :SystemClock[Asia/Calcutta]

	}

}
