// 8. How to add hours in time

package com.cts.training.datetimeapi.day25;

import java.time.LocalTime;

public class AddHoursInTime {

	public static void main(String[] args) {
		LocalTime current = LocalTime.now();

		LocalTime newTime = current.plusHours(2);
		System.out.println("New  time is : " + newTime);

	}

}
