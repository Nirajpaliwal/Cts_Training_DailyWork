// 3. How to get today's date and time

package com.cts.training.datetimeapi.day25;

import java.time.LocalDateTime;

public class GetCurrentDateTime {

	public static void main(String[] args) {

		LocalDateTime dateTime = LocalDateTime.now();
		System.out.println("\nDate & Time : " + dateTime);

	}

}
