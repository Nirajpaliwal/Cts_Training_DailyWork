// 5. How to get a particular date

package com.cts.training.datetimeapi.day25;

import java.time.LocalDate;

public class GetParticularDate {

	public static void main(String[] args) {

		LocalDate birthday = LocalDate.of(1997, 01, 10);
		System.out.println("\nYour birthday is :" + birthday);

	}

}
