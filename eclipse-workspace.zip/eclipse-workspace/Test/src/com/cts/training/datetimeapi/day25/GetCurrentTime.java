// 2. How to get today's current time

package com.cts.training.datetimeapi.day25;

import java.time.LocalTime;

public class GetCurrentTime {

	public static void main(String[] args) {

		LocalTime time = LocalTime.now();
		System.out.println("\nTime : " + time);

	}

}
