// 6. How to check if two dates are equal

package com.cts.training.datetimeapi.day25;

import java.time.LocalDate;

public class CheckDatesEqualOrNot {

	public static void main(String[] args) {

		LocalDate today = LocalDate.now();
		LocalDate birth_day = LocalDate.of(1985, 01, 10);

		if (today.equals(birth_day)) {
			System.out.println("\nDates are equal");
		} else {
			System.out.println("\nDates are  not equal");
		}

	}

}
