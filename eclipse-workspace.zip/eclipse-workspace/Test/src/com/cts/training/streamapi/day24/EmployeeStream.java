package com.cts.training.streamapi.day24;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeStream {

	public static void main(String[] args) {
		ArrayList<Employee> employees = new ArrayList<Employee>();

		addEmployees(employees);

		// 1. with age greater than 20
		List<Employee> ageFilter = employees.stream().filter(e -> e.getAge() > 20).collect(Collectors.toList());
		System.out.println("\nEmployees list where age greater than 20 : \n");
		ageFilter.forEach(System.out::println);

		// 2. employees whose name starts with n

		List<Employee> namesStartsWithN = employees.stream().filter(e -> e.getName().toLowerCase().startsWith("n"))
				.collect(Collectors.toList());
		System.out.println("\nEmployees name starts with N : \n");
		namesStartsWithN.forEach(System.out::println);

		// 3. increase salary of employee by 15% and display employee details
		List<Employee> increaseSalary = employees.stream().map(emp -> {
			emp.setSalary(emp.getSalary() * 1.15);
			return emp;
		}).collect(Collectors.toList());

		System.out.println("\nEmployees Salary increased by 15 % : \n");
		employees.forEach(System.out::println);

		// 4. Add Mr. and Ms. in employee names according to condition
		List<Employee> modifyName = employees.stream().map(emp -> {
			if (emp.getId() % 2 == 0) {
				emp.setName("Mr " + emp.getName());
			} else {
				emp.setName("Ms " + emp.getName());
			}
			return emp;
		}).collect(Collectors.toList());

		System.out.println("\nAdding Mr in even employee id names and Ms in odd employee id names\n");
		employees.forEach(System.out::println);

	}

	private static void addEmployees(ArrayList<Employee> employees) {
		Employee emp1 = new Employee(4234, "Vijay", "Bangalore", "Developer", 20, 1000.00, 79879798L);
		Employee emp2 = new Employee(2324, "Neeraj", "Mumbai", "Software Engineer", 21, 2000.00, 121313L);
		Employee emp3 = new Employee(9987, "Sakshi", "Indore", "Test Engineer", 19, 3000.00, 979879798L);
		Employee emp4 = new Employee(1231, "Neha", "Pune", "DevOps Engineer", 23, 4000.00, 43432222L);
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);

	}

}
